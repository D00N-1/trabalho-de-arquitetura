import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
            new DeliveryFrame().setVisible(true);
        });
    }
}


// ==================== MODEL ====================
class DeliveryOrder {
    private final String id, customer, product, address, carrier, type;
    private final double price;
    private final String[] steps = {"Pedido confirmado", "Preparando pedido", "Em trânsito", "Saiu para entrega", "Entregue"};
    private int statusIndex;

    DeliveryOrder(String id, String customer, String product, String address, String carrier, String type, double price) {
        this.id=id; this.customer=customer; this.product=product; this.address=address;
        this.carrier=carrier; this.type=type; this.price=price; this.statusIndex=0;
    }
    String getId(){return id;} String getCustomer(){return customer;} String getProduct(){return product;}
    String getAddress(){return address;} String getCarrier(){return carrier;} String getType(){return type;}
    double getPrice(){return price;} int getStatusIndex(){return statusIndex;} String getStatus(){return steps[statusIndex];}
    String[] getSteps(){return steps;}
    boolean advance(){ if(statusIndex < steps.length-1){ statusIndex++; return true;} return false; }
}


// ==================== SINGLETON ====================
class OrderRepository {
    private static OrderRepository instance;
    private final java.util.List<DeliveryOrder> orders = new ArrayList<>();
    private OrderRepository() {}
    static synchronized OrderRepository getInstance(){ if(instance==null) instance=new OrderRepository(); return instance; }
    java.util.List<DeliveryOrder> getOrders(){ return Collections.unmodifiableList(orders); }
    void add(DeliveryOrder order){ orders.add(order); }
    void replace(DeliveryOrder oldOrder, DeliveryOrder newOrder){ int i=orders.indexOf(oldOrder); if(i>=0) orders.set(i,newOrder); }
    void remove(DeliveryOrder order){ orders.remove(order); }
}


// ==================== FACTORY METHOD ====================
abstract class ShippingFactory {
    abstract DeliveryOrder createOrder(String id, String customer, String product, String address, double price);
}
class StandardShippingFactory extends ShippingFactory {
    DeliveryOrder createOrder(String id, String customer, String product, String address, double price) {
        return new DeliveryOrder(id, customer, product, address, "Entrega padrão", "Normal", price);
    }
}
class ExpressShippingFactory extends ShippingFactory {
    DeliveryOrder createOrder(String id, String customer, String product, String address, double price) {
        return new DeliveryOrder(id, customer, product, address, "Entrega expressa", "Expressa", price);
    }
}


// ==================== OBSERVER ====================
interface OrderObserver { void onOrderUpdate(DeliveryOrder order, String message); }
class OrderNotifier {
    private final java.util.List<OrderObserver> observers = new ArrayList<>();
    void subscribe(OrderObserver observer){ observers.add(observer); }
    void notifyObservers(DeliveryOrder order, String message){ for(OrderObserver o: observers) o.onOrderUpdate(order, message); }
}


// ==================== UI ====================
class DeliveryFrame extends JFrame implements OrderObserver {
    private final Color NAVY = new Color(28, 48, 78);
    private final Color YELLOW = new Color(255, 204, 0);
    private final Color BG = new Color(244, 246, 249);
    private final OrderRepository repo = OrderRepository.getInstance();
    private final OrderNotifier notifier = new OrderNotifier();
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextArea events;
    private JLabel selectedOrderLabel, statusLabel, addressLabel, productLabel, carrierLabel, priceLabel;
    private JPanel timelinePanel;
    private DeliveryOrder selected;
    private int nextNumber = 1004;


    DeliveryFrame(){
        setTitle("Entrega Express | Central de rastreamento");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1160, 760); setMinimumSize(new Dimension(1000,680)); setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        notifier.subscribe(this);
        seedOrders();
        buildUI();
        refreshTable();
        if(!repo.getOrders().isEmpty()) selectOrder(repo.getOrders().get(0));
        log("Sistema iniciado. Cadastre um pedido ou selecione um da lista.");
    }
    private void seedOrders(){
        repo.add(new StandardShippingFactory().createOrder("PED-1001","Mariana Costa","Fone Bluetooth","Rua Paraná, 540 - Cascavel/PR",189.90));
        DeliveryOrder o2=new ExpressShippingFactory().createOrder("PED-1002","Lucas Almeida","Teclado Mecânico","Av. Brasil, 1200 - Cascavel/PR",249.90);
        repo.add(o2); o2.advance(); o2.advance();
        DeliveryOrder o3=new StandardShippingFactory().createOrder("PED-1003","Fernanda Rocha","Mouse Gamer","Rua Recife, 88 - Toledo/PR",129.90);
        repo.add(o3); o3.advance();
    }
    private void buildUI(){
        setLayout(new BorderLayout());
        add(header(), BorderLayout.NORTH);
        JPanel content=new JPanel(new BorderLayout(14,14)); content.setBackground(BG); content.setBorder(new EmptyBorder(14,16,12,16));
        JPanel left=new JPanel(new BorderLayout(0,12)); left.setBackground(BG); left.setPreferredSize(new Dimension(440,0));
        left.add(orderListPanel(),BorderLayout.CENTER); left.add(newOrderPanel(),BorderLayout.SOUTH);
        JPanel right=new JPanel(new BorderLayout(0,12)); right.setBackground(BG);
        right.add(detailPanel(),BorderLayout.CENTER); right.add(eventPanel(),BorderLayout.SOUTH);
        content.add(left,BorderLayout.WEST); content.add(right,BorderLayout.CENTER);
        add(content,BorderLayout.CENTER);
        add(footer(),BorderLayout.SOUTH);
    }
    private JPanel header(){
        JPanel h=new JPanel(new BorderLayout()); h.setBackground(NAVY); h.setBorder(new EmptyBorder(17,22,17,22));
        JPanel branding=new JPanel(); branding.setOpaque(false); branding.setLayout(new BoxLayout(branding,BoxLayout.Y_AXIS));
        JLabel title=new JLabel("Entrega Express"); title.setFont(new Font("Segoe UI",Font.BOLD,25)); title.setForeground(Color.WHITE);
        JLabel sub=new JLabel("CENTRAL DE PEDIDOS  •  RASTREAMENTO E LOGÍSTICA"); sub.setFont(new Font("Segoe UI",Font.PLAIN,11)); sub.setForeground(new Color(205,218,234));
        branding.add(title); branding.add(Box.createVerticalStrut(3)); branding.add(sub); h.add(branding,BorderLayout.WEST);
        JLabel tag=new JLabel("PAINEL DO OPERADOR"); tag.setOpaque(true); tag.setBackground(new Color(43,66,98)); tag.setForeground(new Color(238,244,250)); tag.setBorder(new EmptyBorder(9,12,9,12)); tag.setFont(new Font("Segoe UI",Font.BOLD,11)); h.add(tag,BorderLayout.EAST);
        return h;
    }
    private JPanel orderListPanel(){
        JPanel p=cardPanel(); p.setLayout(new BorderLayout(0,10)); p.setBorder(new CompoundBorder(new LineBorder(new Color(220,225,232)),new EmptyBorder(13,13,13,13)));
        JLabel heading=sectionTitle("Pedidos cadastrados"); p.add(heading,BorderLayout.NORTH);
        String[] cols={"Pedido","Cliente","Produto","Status"}; tableModel=new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};
        table=new JTable(tableModel); table.setRowHeight(34); table.setFont(new Font("Segoe UI",Font.PLAIN,12)); table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,11)); table.getTableHeader().setBackground(new Color(235,239,244)); table.getTableHeader().setForeground(NAVY);
        table.setShowGrid(false); table.setIntercellSpacing(new Dimension(0,1)); table.setFillsViewportHeight(true);
        table.getSelectionModel().addListSelectionListener(e->{ if(!e.getValueIsAdjusting() && table.getSelectedRow()>=0){ int idx=table.convertRowIndexToModel(table.getSelectedRow()); if(idx<repo.getOrders().size()) selectOrder(repo.getOrders().get(idx)); }});
        JScrollPane tableScroll=new JScrollPane(table);
        p.add(tableScroll,BorderLayout.CENTER);
        JPopupMenu menu=new JPopupMenu();
        JMenuItem detailsItem=new JMenuItem("Ver detalhes do pedido");
        JMenuItem editItem=new JMenuItem("Editar dados");
        JMenuItem copyItem=new JMenuItem("Copiar código de rastreio");
        JMenuItem receiptItem=new JMenuItem("Gerar comprovante");
        JMenuItem cancelItem=new JMenuItem("Cancelar pedido");
        detailsItem.addActionListener(e->showOrderDetails()); editItem.addActionListener(e->editSelectedOrder());
        copyItem.addActionListener(e->copyTrackingCode()); receiptItem.addActionListener(e->showReceipt()); cancelItem.addActionListener(e->cancelSelectedOrder());
        menu.add(detailsItem); menu.add(editItem); menu.add(copyItem); menu.add(receiptItem); menu.addSeparator(); menu.add(cancelItem);
        table.setComponentPopupMenu(menu);
        table.addMouseListener(new MouseAdapter(){ public void mousePressed(MouseEvent e){ if(SwingUtilities.isRightMouseButton(e)){ int row=table.rowAtPoint(e.getPoint()); if(row>=0)table.setRowSelectionInterval(row,row); } if(e.getClickCount()==2 && SwingUtilities.isLeftMouseButton(e)){ showOrderDetails(); } }});
        JLabel count=new JLabel("  Selecione um pedido para acompanhar a entrega"); count.setFont(new Font("Segoe UI",Font.PLAIN,11)); count.setForeground(new Color(110,120,130)); p.add(count,BorderLayout.SOUTH);
        return p;
    }
    private JPanel newOrderPanel(){
        JPanel p=cardPanel(); p.setLayout(new BorderLayout(0,9)); p.setBorder(new CompoundBorder(new LineBorder(new Color(220,225,232)),new EmptyBorder(13,13,13,13)));
        p.add(sectionTitle("Cadastrar novo pedido"),BorderLayout.NORTH);
        JButton add=new JButton("＋  Novo pedido"); stylePrimary(add); add.addActionListener(e->newOrderDialog()); p.add(add,BorderLayout.CENTER); return p;
    }
    private JPanel detailPanel(){
        JPanel p=cardPanel(); p.setLayout(new BorderLayout(0,13)); p.setBorder(new CompoundBorder(new LineBorder(new Color(220,225,232)),new EmptyBorder(16,16,16,16)));
        JPanel top=new JPanel(new BorderLayout()); top.setOpaque(false);
        selectedOrderLabel=new JLabel("Selecione um pedido"); selectedOrderLabel.setFont(new Font("Segoe UI",Font.BOLD,20)); selectedOrderLabel.setForeground(NAVY);
        statusLabel=new JLabel("—"); statusLabel.setFont(new Font("Segoe UI",Font.BOLD,12)); statusLabel.setBorder(new EmptyBorder(8,12,8,12));
        top.add(selectedOrderLabel,BorderLayout.WEST); top.add(statusLabel,BorderLayout.EAST); p.add(top,BorderLayout.NORTH);
        JPanel info=new JPanel(new GridLayout(2,2,10,10)); info.setOpaque(false);
        productLabel=infoLabel("Produto", "—"); addressLabel=infoLabel("Endereço de entrega", "—"); carrierLabel=infoLabel("Modalidade", "—"); priceLabel=infoLabel("Valor", "—");
        info.add(productLabel.getParent()); info.add(addressLabel.getParent()); info.add(carrierLabel.getParent()); info.add(priceLabel.getParent());
        p.add(info,BorderLayout.CENTER);
        JPanel lower=new JPanel(new BorderLayout(0,10)); lower.setOpaque(false);
        JLabel trackTitle=sectionTitle("Acompanhamento da entrega"); lower.add(trackTitle,BorderLayout.NORTH);
        timelinePanel=new JPanel(); timelinePanel.setOpaque(false); timelinePanel.setLayout(new BoxLayout(timelinePanel,BoxLayout.Y_AXIS)); lower.add(timelinePanel,BorderLayout.CENTER);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); actions.setOpaque(false);
        JButton advance=new JButton("Avançar status  →"); stylePrimary(advance); advance.addActionListener(e->advanceSelected());
        JButton reset=new JButton("Reiniciar status"); styleSecondary(reset); reset.addActionListener(e->resetSelected());
        actions.add(advance); actions.add(reset); lower.add(actions,BorderLayout.SOUTH);
        p.add(lower,BorderLayout.SOUTH); return p;
    }
    private JLabel infoLabel(String title,String value){
        JPanel box=new JPanel(new BorderLayout(0,5)); box.setOpaque(true); box.setBackground(new Color(247,249,251)); box.setBorder(new CompoundBorder(new LineBorder(new Color(231,235,239)),new EmptyBorder(10,11,10,11)));
        JLabel t=new JLabel(title.toUpperCase()); t.setFont(new Font("Segoe UI",Font.BOLD,10)); t.setForeground(new Color(120,130,140));
        JLabel v=new JLabel(value); v.setFont(new Font("Segoe UI",Font.PLAIN,13)); v.setForeground(new Color(38,48,58)); box.add(t,BorderLayout.NORTH); box.add(v,BorderLayout.CENTER); return v;
    }
    private JPanel eventPanel(){
        JPanel p=cardPanel(); p.setLayout(new BorderLayout(0,8)); p.setBorder(new CompoundBorder(new LineBorder(new Color(220,225,232)),new EmptyBorder(12,12,12,12)));
        p.add(sectionTitle("Histórico de notificações (Observer)"),BorderLayout.NORTH);
        events=new JTextArea(7,30); events.setEditable(false); events.setFont(new Font("Consolas",Font.PLAIN,11)); events.setBackground(new Color(249,250,252)); events.setForeground(new Color(55,65,75)); events.setBorder(new EmptyBorder(8,9,8,9));
        p.add(new JScrollPane(events),BorderLayout.CENTER); return p;
    }
    private JPanel footer(){ JPanel p=new JPanel(new BorderLayout()); p.setBackground(new Color(232,236,241)); p.setBorder(new EmptyBorder(7,16,7,16)); JLabel l=new JLabel("Entrega Express  |  Projeto acadêmico demonstrando Singleton, Factory Method e Observer"); l.setFont(new Font("Segoe UI",Font.PLAIN,11)); l.setForeground(new Color(90,100,110)); p.add(l,BorderLayout.WEST); return p; }
    private JPanel cardPanel(){ JPanel p=new JPanel(); p.setBackground(Color.WHITE); return p; }
    private JLabel sectionTitle(String s){ JLabel l=new JLabel(s); l.setFont(new Font("Segoe UI",Font.BOLD,14)); l.setForeground(NAVY); return l; }
    private void stylePrimary(JButton b){ b.setBackground(new Color(255,204,0)); b.setForeground(new Color(35,45,55)); b.setFont(new Font("Segoe UI",Font.BOLD,12)); b.setFocusPainted(false); b.setBorder(new EmptyBorder(10,16,10,16)); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); }
    private void styleSecondary(JButton b){ b.setBackground(new Color(236,240,244)); b.setForeground(NAVY); b.setFont(new Font("Segoe UI",Font.BOLD,12)); b.setFocusPainted(false); b.setBorder(new EmptyBorder(10,14,10,14)); }
    private void refreshTable(){ tableModel.setRowCount(0); for(DeliveryOrder o:repo.getOrders()) tableModel.addRow(new Object[]{o.getId(),o.getCustomer(),o.getProduct(),o.getStatus()}); }
    private void selectOrder(DeliveryOrder o){ selected=o; selectedOrderLabel.setText("Pedido "+o.getId()); productLabel.setText(o.getProduct()); addressLabel.setText(o.getAddress()); carrierLabel.setText(o.getCarrier()); priceLabel.setText(String.format("R$ %.2f",o.getPrice()).replace('.',',')); statusLabel.setText(o.getStatus().toUpperCase()); statusLabel.setOpaque(true); statusLabel.setBackground(statusColor(o.getStatusIndex())); statusLabel.setForeground(statusTextColor(o.getStatusIndex())); timeline(); }
    private Color statusColor(int i){ return i==4?new Color(215,244,226):i>=2?new Color(255,239,202):new Color(229,237,248); }
    private Color statusTextColor(int i){ return i==4?new Color(28,120,65):i>=2?new Color(155,95,10):NAVY; }
    private void timeline(){
        timelinePanel.removeAll(); if(selected==null)return;
        String[] steps=selected.getSteps(); int current=selected.getStatusIndex();
        for(int i=0;i<steps.length;i++){
            JPanel row=new JPanel(new BorderLayout(10,0)); row.setOpaque(false); row.setBorder(new EmptyBorder(3,0,3,0));
            JLabel icon=new JLabel(i<current?"●":i==current?"◉":"○"); icon.setPreferredSize(new Dimension(24,22)); icon.setHorizontalAlignment(SwingConstants.CENTER); icon.setFont(new Font("Segoe UI",Font.BOLD,17)); icon.setForeground(i<=current?new Color(30,145,85):new Color(180,190,200));
            JLabel text=new JLabel(steps[i]); text.setFont(new Font("Segoe UI",i==current?Font.BOLD:Font.PLAIN,13)); text.setForeground(i<=current?new Color(40,55,70):new Color(140,150,160));
            row.add(icon,BorderLayout.WEST); row.add(text,BorderLayout.CENTER);
            if(i==current){ JLabel now=new JLabel("ETAPA ATUAL"); now.setFont(new Font("Segoe UI",Font.BOLD,9)); now.setForeground(new Color(30,135,75)); row.add(now,BorderLayout.EAST); }
            timelinePanel.add(row);
        }
        timelinePanel.revalidate(); timelinePanel.repaint();
    }
    private void advanceSelected(){ if(selected==null){message("Selecione um pedido primeiro.");return;} if(selected.advance()){refreshTable();selectOrder(selected);notifier.notifyObservers(selected,"Status atualizado para: "+selected.getStatus());}else message("Este pedido já foi entregue."); }
    private void resetSelected(){ if(selected==null)return; // reset by creating replacement record at same position for this demo
        message("Para reiniciar, cadastre um novo pedido. O rastreamento não retrocede após a entrega."); }
    private void showOrderDetails(){
        if(selected==null){message("Selecione um pedido primeiro.");return;}
        String info="Pedido: "+selected.getId()+"\nCliente: "+selected.getCustomer()+"\nProduto: "+selected.getProduct()+"\nEndereço: "+selected.getAddress()+"\nEntrega: "+selected.getCarrier()+"\nValor: R$ "+String.format("%.2f",selected.getPrice())+"\nStatus: "+selected.getStatus();
        JOptionPane.showMessageDialog(this,info,"Detalhes do pedido",JOptionPane.INFORMATION_MESSAGE);
    }
    private void copyTrackingCode(){ if(selected==null){message("Selecione um pedido primeiro.");return;} Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new java.awt.datatransfer.StringSelection(selected.getId()),null); message("Código "+selected.getId()+" copiado!"); }
    private void showReceipt(){ if(selected==null){message("Selecione um pedido primeiro.");return;} String receipt="COMPROVANTE DE PEDIDO\n\nCódigo: "+selected.getId()+"\nCliente: "+selected.getCustomer()+"\nProduto: "+selected.getProduct()+"\nDestino: "+selected.getAddress()+"\nModalidade: "+selected.getCarrier()+"\nValor: R$ "+String.format("%.2f",selected.getPrice())+"\nStatus: "+selected.getStatus(); JOptionPane.showMessageDialog(this,receipt,"Comprovante",JOptionPane.INFORMATION_MESSAGE); }
    private void cancelSelectedOrder(){ if(selected==null){message("Selecione um pedido primeiro.");return;} int confirm=JOptionPane.showConfirmDialog(this,"Deseja cancelar o pedido "+selected.getId()+"?","Confirmar cancelamento",JOptionPane.YES_NO_OPTION); if(confirm==JOptionPane.YES_OPTION){DeliveryOrder removed=selected;repo.remove(removed);selected=null;refreshTable();if(!repo.getOrders().isEmpty())selectOrder(repo.getOrders().get(0));else clearDetails();log("Pedido "+removed.getId()+" cancelado.");} }
    private void clearDetails(){selectedOrderLabel.setText("Selecione um pedido");productLabel.setText("—");addressLabel.setText("—");carrierLabel.setText("—");priceLabel.setText("—");statusLabel.setText("—");timelinePanel.removeAll();timelinePanel.revalidate();timelinePanel.repaint();}
    private void editSelectedOrder(){ if(selected==null){message("Selecione um pedido primeiro.");return;} JTextField customer=new JTextField(selected.getCustomer()), product=new JTextField(selected.getProduct()), address=new JTextField(selected.getAddress()); JPanel form=new JPanel(new GridLayout(0,2,8,8)); form.add(new JLabel("Cliente:"));form.add(customer);form.add(new JLabel("Produto:"));form.add(product);form.add(new JLabel("Endereço:"));form.add(address); int result=JOptionPane.showConfirmDialog(this,form,"Editar pedido "+selected.getId(),JOptionPane.OK_CANCEL_OPTION); if(result==JOptionPane.OK_OPTION){if(customer.getText().trim().isEmpty()||product.getText().trim().isEmpty()||address.getText().trim().isEmpty()){message("Preencha todos os campos.");return;} DeliveryOrder old=selected; DeliveryOrder updated=new DeliveryOrder(old.getId(),customer.getText().trim(),product.getText().trim(),address.getText().trim(),old.getCarrier(),old.getType(),old.getPrice());for(int i=0;i<old.getStatusIndex();i++)updated.advance();repo.replace(old,updated);refreshTable();selectOrder(updated);notifier.notifyObservers(updated,"Dados do pedido editados.");}}
    private void newOrderDialog(){
        JTextField customer=new JTextField(20), product=new JTextField(20), address=new JTextField(20), price=new JTextField(10);
        JComboBox<String> shipping=new JComboBox<>(new String[]{"Entrega padrão","Entrega expressa"});
        JPanel form=new JPanel(new GridLayout(0,2,8,8)); form.setBorder(new EmptyBorder(8,8,8,8));
        form.add(new JLabel("Cliente:")); form.add(customer); form.add(new JLabel("Produto:")); form.add(product); form.add(new JLabel("Endereço:")); form.add(address); form.add(new JLabel("Valor (R$):")); form.add(price); form.add(new JLabel("Tipo de envio:")); form.add(shipping);
        int result=JOptionPane.showConfirmDialog(this,form,"Cadastrar pedido",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
        if(result==JOptionPane.OK_OPTION){
            try{ if(customer.getText().trim().isEmpty()||product.getText().trim().isEmpty()||address.getText().trim().isEmpty())throw new IllegalArgumentException("Preencha todos os campos."); double v=Double.parseDouble(price.getText().replace(',','.')); if(v<0)throw new IllegalArgumentException("Valor inválido."); String id=String.format("PED-%04d",nextNumber++); ShippingFactory factory=shipping.getSelectedIndex()==0?new StandardShippingFactory():new ExpressShippingFactory(); DeliveryOrder order=factory.createOrder(id,customer.getText().trim(),product.getText().trim(),address.getText().trim(),v); repo.add(order); refreshTable(); selectOrder(order); notifier.notifyObservers(order,"Novo pedido cadastrado: "+id); log("Pedido "+id+" criado e aguardando preparação."); }
            catch(Exception ex){message("Dados inválidos: "+ex.getMessage());}
        }
    }
    private void log(String msg){ if(events==null)return; String time=new SimpleDateFormat("HH:mm:ss").format(new Date()); events.append("["+time+"] "+msg+"\n"); events.setCaretPosition(events.getDocument().getLength()); }
    public void onOrderUpdate(DeliveryOrder order,String message){ log("Observer → "+order.getId()+": "+message); }
    private void message(String s){JOptionPane.showMessageDialog(this,s,"Entrega Express",JOptionPane.INFORMATION_MESSAGE);}
}

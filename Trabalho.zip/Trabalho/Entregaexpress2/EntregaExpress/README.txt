ENTREGA EXPRESS - JAVA SWING

Como executar:
1. Abra esta pasta no terminal.
2. Execute: javac Main.java
3. Execute: java Main

Opcoes adicionadas nesta versao:
- Menu de contexto ao clicar com botao direito em um pedido
- Ver detalhes do pedido
- Editar cliente, produto e endereco
- Copiar codigo de rastreio
- Exibir comprovante
- Cancelar pedido com confirmacao
- Duplo clique no pedido para abrir detalhes

Padroes mantidos: Singleton, Factory Method e Observer.
